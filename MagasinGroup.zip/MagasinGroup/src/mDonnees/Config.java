package mDonnees;

public class Config {
	public static String dbName = "gestionmagasin7";
	public static String appName = "Gestion Magasin";
}
